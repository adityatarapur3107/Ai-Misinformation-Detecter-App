import { Shield, ShieldCheck, User } from 'lucide-react';

export function TopAppBar() {
  return (
    <header className="fixed top-0 w-full z-50 flex justify-between items-center px-6 pt-12 pb-4 max-w-[400px] bg-surface/70 backdrop-blur-2xl">
      <div className="flex items-center gap-2">
        <Shield className="w-6 h-6 text-primary fill-primary/10" />
        <h1 className="text-xl font-bold text-primary tracking-tighter">AI Sentinel</h1>
      </div>
      <div className="flex items-center gap-3">
        <div className="px-2.5 py-1 rounded-full bg-primary-container/10 border border-primary/10">
          <span className="text-[10px] font-bold uppercase tracking-widest text-primary">Privacy Safe</span>
        </div>
        <div className="w-8 h-8 rounded-full overflow-hidden border border-white/50 bg-surface-container-highest">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop" 
            alt="User" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    </header>
  );
}
