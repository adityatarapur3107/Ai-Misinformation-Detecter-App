import { Radar, AlertTriangle, Sparkles, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface WhatsAppViewProps {
  onShowAnalysis: () => void;
}

export function WhatsAppView({ onShowAnalysis }: WhatsAppViewProps) {
  return (
    <div className="flex-1 overflow-y-auto pt-28 pb-32 px-4 space-y-6 no-scrollbar">
      {/* Real-Time Protection Toggle */}
      <section className="glass-card rounded-2xl p-4 shadow-sm relative overflow-hidden border border-white/40">
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Radar className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold text-on-surface">Real-Time Protection</p>
              <p className="text-[11px] text-on-surface-variant font-medium">Scanning WhatsApp Messages</p>
            </div>
          </div>
          <div className="w-12 h-6 bg-primary rounded-full relative flex items-center px-1">
            <div className="w-4 h-4 bg-white rounded-full translate-x-6" />
          </div>
        </div>
        {/* Scan Animation */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent pointer-events-none"
          animate={{ x: ['-100%', '200%'] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        />
      </section>

      {/* Chat Container */}
      <div className="space-y-6">
        {/* Received Message (High Risk Example) */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-start max-w-[85%]"
        >
          <div className="bg-white/90 backdrop-blur-md rounded-2xl rounded-tl-sm p-3.5 shadow-sm border border-white/50">
            <p className="text-sm text-on-surface leading-relaxed">
              ⚠️ Urgent: The government is shutting down all social media tonight at 8 PM. Forward this to 10 people to keep your account active.
            </p>
            {/* Small AI Badge */}
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-error" />
                <span className="text-[10px] font-bold uppercase tracking-wide text-error">High Risk</span>
              </div>
              <div className="px-2 py-0.5 rounded-md bg-error/10 text-error text-[10px] font-black">
                94% ACCURACY
              </div>
            </div>
          </div>
          <span className="text-[10px] text-on-surface-variant/60 mt-1 ml-1 font-medium">10:42 AM</span>
        </motion.div>

        {/* AI Insight Card (Bento Style) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card rounded-3xl p-5 border border-white/60 shadow-lg"
        >
          <div className="flex items-start justify-between mb-4">
            <h3 className="text-sm font-bold text-on-surface tracking-tight">Sentinel Insight</h3>
            <Sparkles className="w-5 h-5 text-primary-container" />
          </div>
          <p className="text-xs text-on-surface-variant leading-relaxed mb-4">
            This message matches known patterns of <span className="font-bold text-primary">viral disinformation</span> spread via coordinated bot networks. Sources verified by AFP and Reuters confirm this is false.
          </p>
          <button 
            onClick={onShowAnalysis}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-primary to-primary-container text-white text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition-transform"
          >
            See Fact-Check Sources
          </button>
        </motion.div>

        {/* Received Message (Low Risk Example) */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col items-start max-w-[85%]"
        >
          <div className="bg-white/90 backdrop-blur-md rounded-2xl rounded-tl-sm p-3.5 shadow-sm border border-white/50">
            <p className="text-sm text-on-surface leading-relaxed">
              Hey! Did you see the match last night? The last goal was incredible. Let's catch up later?
            </p>
            {/* Small AI Badge */}
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-secondary" />
                <span className="text-[10px] font-bold uppercase tracking-wide text-secondary">Low Risk</span>
              </div>
              <div className="px-2 py-0.5 rounded-md bg-secondary/10 text-secondary text-[10px] font-black">
                82% SAFE
              </div>
            </div>
          </div>
          <span className="text-[10px] text-on-surface-variant/60 mt-1 ml-1 font-medium">11:15 AM</span>
        </motion.div>

        {/* User Message */}
        <div className="flex flex-col items-end w-full">
          <div className="bg-primary text-white rounded-2xl rounded-tr-sm p-3.5 shadow-md max-w-[80%]">
            <p className="text-sm leading-relaxed font-medium">
              Thanks Sentinel. I'll make sure to report that viral message.
            </p>
          </div>
          <span className="text-[10px] text-on-surface-variant/60 mt-1 mr-1 font-medium">11:16 AM</span>
        </div>
      </div>
    </div>
  );
}
