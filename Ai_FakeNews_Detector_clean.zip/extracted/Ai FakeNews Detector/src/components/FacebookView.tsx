import { Shield, MoreHorizontal, AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { motion } from 'motion/react';

export function FacebookView() {
  return (
    <div className="flex-1 overflow-y-auto pt-28 pb-32 px-4 space-y-6 no-scrollbar">
      {/* Active Protection Toggle */}
      <section className="glass-card rounded-xl p-4 flex items-center justify-between shadow-sm relative overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-bold text-on-surface">Active Protection</p>
            <p className="text-[11px] text-on-surface-variant">Scanning feed for deepfakes</p>
          </div>
        </div>
        <div className="w-12 h-6 bg-primary rounded-full relative flex items-center px-1">
          <div className="w-4 h-4 bg-white rounded-full ml-auto shadow-sm" />
        </div>
        {/* Laser Scan Line */}
        <motion.div 
          className="absolute top-0 left-0 w-full h-0.5 bg-primary shadow-[0_0_15px_#0070eb] z-40 pointer-events-none"
          animate={{ top: ['0%', '100%', '0%'] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
        />
      </section>

      {/* Feed Items */}
      <div className="space-y-6">
        {/* Post 1: High Risk */}
        <article className="glass-card rounded-xl overflow-hidden shadow-lg border-l-4 border-error">
          <div className="p-4 flex items-center justify-between border-b border-outline-variant/10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center overflow-hidden">
                <img 
                  className="w-full h-full object-cover" 
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop" 
                  alt="User"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <p className="text-xs font-bold text-on-surface">Global News Network</p>
                <p className="text-[10px] text-on-surface-variant">Sponsored · 2h ago</p>
              </div>
            </div>
            <MoreHorizontal className="w-4 h-4 text-on-surface-variant" />
          </div>
          <div className="p-4 space-y-3">
            <p className="text-sm leading-relaxed text-on-surface">Breaking: Markets react as new regulation bill is passed overnight in a closed-door session. Citizens are urged to verify their digital identity.</p>
            <div className="rounded-lg overflow-hidden h-40 bg-surface-container">
              <img 
                className="w-full h-full object-cover" 
                src="https://images.unsplash.com/photo-1611974714658-66d2c1360a22?w=600&h=400&fit=crop" 
                alt="Market Chart"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="bg-error/5 p-4 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold uppercase text-error tracking-widest">Risk Level: High</span>
              <div className="flex items-center gap-1">
                <AlertCircle className="w-3 h-3 text-error fill-error/10" />
                <span className="text-xs font-semibold text-error">Synthetically Altered</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-on-surface-variant uppercase font-bold">Confidence</span>
              <p className="text-lg font-black text-error">94%</p>
            </div>
          </div>
        </article>

        {/* Post 2: Verified Safe */}
        <article className="glass-card rounded-xl overflow-hidden shadow-lg border-l-4 border-secondary">
          <div className="p-4 flex items-center justify-between border-b border-outline-variant/10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center overflow-hidden">
                <img 
                  className="w-full h-full object-cover" 
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop" 
                  alt="User"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <p className="text-xs font-bold text-on-surface">Tech Insider</p>
                <p className="text-[10px] text-on-surface-variant">5h ago</p>
              </div>
            </div>
            <MoreHorizontal className="w-4 h-4 text-on-surface-variant" />
          </div>
          <div className="p-4 space-y-3">
            <p className="text-sm leading-relaxed text-on-surface">New sustainable energy initiative launched in the city center. Reducing carbon footprint by 30% by 2025.</p>
          </div>
          <div className="bg-secondary/5 p-4 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold uppercase text-secondary tracking-widest">Risk Level: Safe</span>
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-secondary fill-secondary/10" />
                <span className="text-xs font-semibold text-secondary">Verified Source</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-on-surface-variant uppercase font-bold">Confidence</span>
              <p className="text-lg font-black text-secondary">99%</p>
            </div>
          </div>
        </article>

        {/* Post 3: Moderate Risk */}
        <article className="glass-card rounded-xl overflow-hidden shadow-lg border-l-4 border-tertiary">
          <div className="p-4 flex items-center justify-between border-b border-outline-variant/10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center overflow-hidden">
                <img 
                  className="w-full h-full object-cover" 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" 
                  alt="User"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <p className="text-xs font-bold text-on-surface">Community Forum</p>
                <p className="text-[10px] text-on-surface-variant">12m ago</p>
              </div>
            </div>
            <MoreHorizontal className="w-4 h-4 text-on-surface-variant" />
          </div>
          <div className="p-4 space-y-3">
            <p className="text-sm leading-relaxed text-on-surface">Is anyone else seeing these weird lights over the harbor tonight? Seems out of the ordinary.</p>
            <div className="rounded-lg overflow-hidden h-40 bg-surface-container">
              <img 
                className="w-full h-full object-cover" 
                src="https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?w=600&h=400&fit=crop" 
                alt="Harbor"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="bg-tertiary/5 p-4 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold uppercase text-tertiary tracking-widest">Risk Level: Moderate</span>
              <div className="flex items-center gap-1">
                <Info className="w-3 h-3 text-tertiary" />
                <span className="text-xs font-semibold text-tertiary">Unverified Media</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-on-surface-variant uppercase font-bold">Confidence</span>
              <p className="text-lg font-black text-tertiary">62%</p>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}
