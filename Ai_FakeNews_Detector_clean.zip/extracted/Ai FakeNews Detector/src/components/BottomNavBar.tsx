import { LayoutDashboard, Instagram, MessageCircle, Settings, Lock, Shield } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export type ViewType = 'whatsapp' | 'instagram' | 'facebook' | 'history';

interface BottomNavBarProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
}

export function BottomNavBar({ activeView, onViewChange }: BottomNavBarProps) {
  return (
    <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[90%] max-w-[360px] z-50 flex justify-around items-center p-2 bg-white/80 backdrop-blur-xl rounded-full shadow-[0_20px_40px_rgba(0,26,65,0.06)]">
      <button 
        onClick={() => onViewChange('facebook')}
        className={cn(
          "flex flex-col items-center justify-center px-4 py-2 transition-all rounded-full",
          activeView === 'facebook' ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-gray-400 hover:text-gray-900"
        )}
      >
        <LayoutDashboard className="w-5 h-5" />
        <span className="text-[10px] font-semibold tracking-wide mt-0.5">Facebook</span>
      </button>

      <button 
        onClick={() => onViewChange('instagram')}
        className={cn(
          "flex flex-col items-center justify-center px-4 py-2 transition-all rounded-full",
          activeView === 'instagram' ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-gray-400 hover:text-gray-900"
        )}
      >
        <Instagram className="w-5 h-5" />
        <span className="text-[10px] font-semibold tracking-wide mt-0.5">Instagram</span>
      </button>

      <button 
        onClick={() => onViewChange('whatsapp')}
        className={cn(
          "flex flex-col items-center justify-center px-4 py-2 transition-all rounded-full",
          activeView === 'whatsapp' ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-gray-400 hover:text-gray-900"
        )}
      >
        <MessageCircle className="w-5 h-5" />
        <span className="text-[10px] font-semibold tracking-wide mt-0.5">WhatsApp</span>
      </button>

      <button 
        onClick={() => onViewChange('history')}
        className={cn(
          "flex flex-col items-center justify-center px-4 py-2 transition-all rounded-full",
          activeView === 'history' ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-gray-400 hover:text-gray-900"
        )}
      >
        <Shield className="w-5 h-5" />
        <span className="text-[10px] font-semibold tracking-wide mt-0.5">History</span>
      </button>
    </nav>
  );
}
