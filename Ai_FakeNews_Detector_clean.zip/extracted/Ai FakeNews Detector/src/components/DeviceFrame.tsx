import React from 'react';
import { cn } from '@/src/lib/utils';

interface DeviceFrameProps {
  children: React.ReactNode;
  className?: string;
}

export function DeviceFrame({ children, className }: DeviceFrameProps) {
  return (
    <div className="flex items-center justify-center min-h-screen p-4 md:p-8">
      <div className={cn(
        "relative w-full max-w-[400px] h-[844px] bg-surface rounded-[3.5rem] overflow-hidden flex flex-col mesh-gradient shadow-2xl border-[12px] border-white",
        className
      )}>
        {/* Dynamic Island Area */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-32 h-9 bg-black rounded-full z-[100] flex items-center justify-center px-4">
          <div className="flex items-center gap-2 w-full justify-between">
            <div className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />
            <div className="h-1 w-12 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-secondary w-2/3" />
            </div>
            <span className="text-[10px] text-white font-bold tracking-tighter">94%</span>
          </div>
        </div>

        {/* Home Indicator */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-black/10 rounded-full z-50" />
        
        {children}
      </div>
    </div>
  );
}
