import { Search, MessageSquare, Instagram, MessageCircle, Mail } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { motion } from 'motion/react';

const HISTORY_ITEMS = [
  {
    id: 1,
    platform: 'Facebook Messenger',
    icon: MessageSquare,
    color: 'from-blue-600 to-blue-400',
    date: 'Oct 24, 2023 • 14:32',
    risk: 'High Risk',
    riskColor: 'text-error bg-error/10 border-error',
    confidence: '94%',
    message: 'Potentially malicious link detected in message from +1 555-0192'
  },
  {
    id: 2,
    platform: 'Instagram',
    icon: Instagram,
    color: 'from-pink-500 to-purple-600',
    date: 'Oct 24, 2023 • 09:15',
    risk: 'Medium Risk',
    riskColor: 'text-tertiary bg-tertiary/10 border-tertiary',
    confidence: '82%',
    message: 'AI manipulation signature found in post by @deepfake_detector'
  },
  {
    id: 3,
    platform: 'WhatsApp',
    icon: MessageCircle,
    color: 'from-green-500 to-emerald-600',
    date: 'Oct 23, 2023 • 22:10',
    risk: 'Low Risk',
    riskColor: 'text-secondary bg-secondary/10 border-secondary',
    confidence: '98%',
    message: 'Voice note scan completed. Content verified as Authentic.'
  },
  {
    id: 4,
    platform: 'Direct Scan',
    icon: Mail,
    color: 'from-slate-700 to-slate-900',
    date: 'Oct 23, 2023 • 18:05',
    risk: 'High Risk',
    riskColor: 'text-error bg-error/10 border-error',
    confidence: '91%',
    message: 'Synthetic voice fingerprint detected in uploaded audio_01.mp3'
  }
];

export function ScanHistory() {
  return (
    <div className="flex-1 overflow-y-auto pt-28 pb-32 px-5 space-y-6 no-scrollbar">
      {/* Section Header */}
      <div className="space-y-1">
        <span className="text-[0.6875rem] font-bold uppercase tracking-[0.1em] text-on-surface-variant/70">Security Ledger</span>
        <h1 className="text-[2.25rem] font-extrabold tracking-tight text-on-surface leading-tight">Scan History</h1>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <div className="glass-card rounded-full flex items-center px-4 py-3 shadow-sm border border-white/20">
          <Search className="w-4 h-4 text-on-surface-variant/60 mr-2" />
          <input 
            type="text" 
            placeholder="Search scans..." 
            className="bg-transparent border-none focus:ring-0 text-sm w-full placeholder:text-on-surface-variant/50 text-on-surface"
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="relative -mx-5 px-5 mb-6 overflow-hidden">
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1">
          <button className="flex-none bg-primary text-white px-4 py-1.5 rounded-full text-sm font-medium shadow-sm">
            All
          </button>
          {['Facebook', 'Instagram', 'WhatsApp', 'Telegram'].map((platform) => (
            <button 
              key={platform}
              className="flex-none bg-white/40 backdrop-blur-md border border-white/20 text-on-surface px-4 py-1.5 rounded-full text-sm font-medium hover:bg-white/60 transition-all"
            >
              {platform}
            </button>
          ))}
        </div>
      </div>

      {/* History Items */}
      <div className="grid grid-cols-1 gap-6">
        {HISTORY_ITEMS.map((item) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card rounded-3xl p-5 shadow-sm transition-transform active:scale-[0.98]"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-2xl bg-gradient-to-br flex items-center justify-center text-white shadow-lg",
                  item.color
                )}>
                  <item.icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-on-surface">{item.platform}</h3>
                  <p className="text-[11px] text-on-surface-variant font-medium">{item.date}</p>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className={cn(
                  "text-[10px] px-2 py-0.5 rounded-md font-bold uppercase tracking-wider mb-1",
                  item.riskColor.split(' ').slice(0, 2).join(' ')
                )}>
                  {item.risk}
                </span>
                <span className="text-xs font-bold text-on-surface">{item.confidence} Confidence</span>
              </div>
            </div>
            <div className={cn(
              "bg-surface-container-low/50 rounded-xl p-3 mb-4 border-l-4",
              item.riskColor.split(' ').pop()
            )}>
              <p className="text-sm text-on-surface leading-relaxed">
                {item.message}
              </p>
            </div>
            <button className="w-full py-2.5 bg-surface-container-highest rounded-xl text-xs font-bold tracking-wide text-on-surface hover:bg-surface-container-high transition-colors">
              View Details
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
