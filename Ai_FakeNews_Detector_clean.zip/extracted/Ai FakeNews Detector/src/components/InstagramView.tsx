import { Heart, MessageCircle, Send, ShieldAlert, ShieldCheck, MoreHorizontal } from 'lucide-react';
import { motion } from 'motion/react';

export function InstagramView() {
  return (
    <div className="flex-1 overflow-y-auto pt-28 pb-32 px-4 space-y-8 no-scrollbar">
      {/* Real-Time Analysis Toggle */}
      <section>
        <div className="glass-card rounded-3xl p-5 shadow-sm border border-white/40 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-on-surface text-lg tracking-tight">Real-Time Analysis</h3>
            <p className="text-xs text-on-surface-variant font-medium">Scanning incoming visual data</p>
          </div>
          <div className="w-14 h-8 bg-primary rounded-full relative p-1 flex items-center justify-end">
            <div className="w-6 h-6 bg-white rounded-full shadow-md" />
          </div>
        </div>
      </section>

      {/* Feed Items */}
      <div className="space-y-8">
        {/* Post 1: High Risk */}
        <article className="glass-card rounded-[2rem] overflow-hidden shadow-xl shadow-blue-900/5 relative">
          <div className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full border-2 border-primary p-0.5">
              <img 
                className="w-full h-full rounded-full object-cover" 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" 
                alt="User"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <p className="text-sm font-bold text-on-surface">cyber_observer</p>
              <p className="text-[10px] text-on-surface-variant">Global News Feed • 2m ago</p>
            </div>
          </div>
          
          <div className="relative px-4">
            <div className="aspect-[4/5] w-full rounded-3xl overflow-hidden relative">
              <img 
                className="w-full h-full object-cover" 
                src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=600&h=750&fit=crop" 
                alt="Futuristic City"
                referrerPolicy="no-referrer"
              />
              {/* AI Risk Badge */}
              <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
                <div className="bg-error/90 backdrop-blur-md px-3 py-2 rounded-2xl flex items-center gap-2 shadow-lg">
                  <ShieldAlert className="w-4 h-4 text-white" />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-bold text-white/80 leading-none uppercase">Risk Level</span>
                    <span className="text-xs font-black text-white leading-tight">HIGH</span>
                  </div>
                </div>
                <div className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-xl shadow-md">
                  <span className="text-[10px] font-bold text-on-surface">Confidence: <span className="text-error">94%</span></span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5">
            <div className="flex gap-4 mb-4">
              <Heart className="w-6 h-6 text-on-surface-variant" />
              <MessageCircle className="w-6 h-6 text-on-surface-variant" />
              <Send className="w-6 h-6 text-on-surface-variant" />
            </div>
            <p className="text-sm leading-relaxed text-on-surface">
              <span className="font-bold">cyber_observer</span> Breaking: New architectural phenomenon discovered in the heart of the digital district. 
              <span className="text-primary-container font-medium ml-1">#FutureTech #AI</span>
            </p>
            <div className="mt-4 bg-error-container/40 p-3 rounded-2xl border-l-4 border-error">
              <p className="text-[11px] font-semibold text-on-error-container">AI Sentinel Flag: This image shows signs of neural synthesis and metadata inconsistencies typical of generative AI.</p>
            </div>
          </div>

          {/* Laser Scan Animation */}
          <motion.div 
            className="absolute top-0 left-0 w-full h-0.5 bg-primary shadow-[0_0_15px_#0070eb] z-40 pointer-events-none"
            animate={{ top: ['0%', '100%', '0%'] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          />
        </article>

        {/* Post 2: Verified Safe */}
        <article className="glass-card rounded-[2rem] overflow-hidden shadow-xl shadow-blue-900/5">
          <div className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full border-2 border-secondary p-0.5">
              <img 
                className="w-full h-full rounded-full object-cover" 
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop" 
                alt="User"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <p className="text-sm font-bold text-on-surface">natura_pixel</p>
              <p className="text-[10px] text-on-surface-variant">Authentic Moments • 15m ago</p>
            </div>
          </div>
          
          <div className="relative px-4">
            <div className="aspect-square w-full rounded-3xl overflow-hidden relative">
              <img 
                className="w-full h-full object-cover" 
                src="https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&h=600&fit=crop" 
                alt="Nature"
                referrerPolicy="no-referrer"
              />
              {/* AI Safe Badge */}
              <div className="absolute top-4 right-4">
                <div className="bg-secondary/90 backdrop-blur-md px-3 py-2 rounded-2xl flex items-center gap-2 shadow-lg">
                  <ShieldCheck className="w-4 h-4 text-white" />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-bold text-white/80 leading-none uppercase">Authentic</span>
                    <span className="text-xs font-black text-white leading-tight">VERIFIED</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5">
            <div className="flex gap-4 mb-4">
              <Heart className="w-6 h-6 text-on-surface-variant" />
              <MessageCircle className="w-6 h-6 text-on-surface-variant" />
              <Send className="w-6 h-6 text-on-surface-variant" />
            </div>
            <p className="text-sm text-on-surface">
              <span className="font-bold">natura_pixel</span> Mornings like these are meant for silence. Captured on film.
            </p>
          </div>
        </article>
      </div>
    </div>
  );
}
