import { Brain, ShieldCheck, ShieldAlert, ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AnalysisModal({ isOpen, onClose }: AnalysisModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-on-background/20 z-[70] backdrop-blur-sm"
          />
          <motion.div 
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute bottom-0 left-0 right-0 glass-card rounded-t-[2.5rem] p-8 flex flex-col items-center shadow-[0_-10px_40px_rgba(0,0,0,0.08)] z-[80]"
          >
            {/* Handle Bar */}
            <div className="w-12 h-1.5 bg-outline-variant/30 rounded-full mb-8" />
            
            {/* Circular Progress Ring */}
            <div className="relative w-48 h-48 mb-8 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90">
                <circle 
                  className="text-surface-container-highest" 
                  cx="96" cy="96" r="80" 
                  fill="transparent" 
                  stroke="currentColor" 
                  strokeWidth="12" 
                />
                <motion.circle 
                  className="text-tertiary" 
                  cx="96" cy="96" r="80" 
                  fill="transparent" 
                  stroke="currentColor" 
                  strokeWidth="12" 
                  strokeDasharray="502.65"
                  initial={{ strokeDashoffset: 502.65 }}
                  animate={{ strokeDashoffset: 502.65 * (1 - 0.78) }}
                  transition={{ duration: 1.5, ease: 'easeOut' }}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-4xl font-black text-on-surface tracking-tighter leading-none">78%</span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-on-surface-variant mt-1">Fake Probability</span>
              </div>
            </div>

            {/* Bento Style Insight Cards */}
            <div className="w-full grid grid-cols-1 gap-4 mb-10">
              {/* AI Reasoning Card */}
              <div className="bg-white/80 p-5 rounded-xl border-l-4 border-tertiary shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Brain className="w-4 h-4 text-tertiary" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-on-surface-variant">AI Reasoning</h3>
                </div>
                <p className="text-sm leading-relaxed text-on-surface font-medium italic">
                  "Spectral analysis detected inorganic pixel patterns in the ocular regions. Contextual semantic drift suggests high manipulative intent."
                </p>
              </div>

              {/* Recommended Action Card */}
              <div className="bg-white/80 p-5 rounded-xl border-l-4 border-secondary shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-4 h-4 text-secondary" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-on-surface-variant">Recommended Action</h3>
                </div>
                <div className="flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-secondary mt-0.5" />
                  <p className="text-sm leading-snug text-on-surface-variant">
                    Verification recommended. Avoid sharing until cross-referenced with 3 trusted sources.
                  </p>
                </div>
              </div>
            </div>

            {/* Primary CTA */}
            <button className="group relative w-full h-16 bg-gradient-to-r from-primary to-tertiary rounded-xl overflow-hidden flex items-center justify-center gap-3 transition-transform active:scale-[0.98]">
              <span className="text-white font-bold tracking-tight text-lg">Deep Scan Output</span>
              <ChevronRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
              <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
            
            <p className="mt-4 text-[10px] font-semibold text-outline tracking-wider uppercase">
              AI Sentinel • Encrypted Report
            </p>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
