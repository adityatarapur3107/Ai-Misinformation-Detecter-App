import { useState } from 'react';
import { DeviceFrame } from './components/DeviceFrame';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar, type ViewType } from './components/BottomNavBar';
import { WhatsAppView } from './components/WhatsAppView';
import { InstagramView } from './components/InstagramView';
import { FacebookView } from './components/FacebookView';
import { ScanHistory } from './components/ScanHistory';
import { AnalysisModal } from './components/AnalysisModal';

export default function App() {
  const [activeView, setActiveView] = useState<ViewType>('whatsapp');
  const [isAnalysisOpen, setIsAnalysisOpen] = useState(false);

  const renderView = () => {
    switch (activeView) {
      case 'whatsapp':
        return <WhatsAppView onShowAnalysis={() => setIsAnalysisOpen(true)} />;
      case 'instagram':
        return <InstagramView />;
      case 'facebook':
        return <FacebookView />;
      case 'history':
        return <ScanHistory />;
      default:
        return <WhatsAppView onShowAnalysis={() => setIsAnalysisOpen(true)} />;
    }
  };

  return (
    <DeviceFrame>
      <TopAppBar />
      
      {renderView()}

      <BottomNavBar 
        activeView={activeView} 
        onViewChange={setActiveView} 
      />

      <AnalysisModal 
        isOpen={isAnalysisOpen} 
        onClose={() => setIsAnalysisOpen(false)} 
      />
    </DeviceFrame>
  );
}
